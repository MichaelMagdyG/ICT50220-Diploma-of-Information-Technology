
<h2>Welcome to Flower Power</h2>
<p><a href="register.php">Register</a> | <a href="login.php">Login</a></p>
